import React from 'react';

const LaguDaerah = ({ nama, asal }) => {
  return (
    <div className="flex justify-center">
      <div className="group rounded-[38px] border-ivory border-[5px] flex flex-col items-center justify-center lg:w-[300px] lg:h-[300px] mb-10 drop-shadow-md hover:bg-ivory duration-300">
        <h1 className="uppercase font-raja leading-tight text-ivory lg:text-[48px] text-[35px] text-center mx-2 group-hover:text-burgundy duration-300">{nama}</h1>
        <p className="font-bhadra text-ivory lg:text-[18px] text-[14px] text-center mb-2 group-hover:text-burgundy mt-[-5px] duration-300">FROM</p>
        <p className="uppercase font-bhadra text-ivory lg:text-[24px] text-[15px] text-center mx-1 group-hover:text-burgundy duration-300 mt-[-5px]">{asal}</p>
      </div>
    </div>
  );
};

export default LaguDaerah;
