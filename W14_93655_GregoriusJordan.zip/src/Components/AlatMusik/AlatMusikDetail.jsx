

const AlatMusikDetails = () => {
    return(
        <div>

        </div>
    );
};

export default AlatMusikDetails;