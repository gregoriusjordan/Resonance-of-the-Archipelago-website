

const Footer= () => {
    return (
        <div className="bg-ivory h-[150px] w-100%">
            <h1 className="font-burgundy font-quick text-xl ">Resonance of The Archipelago</h1>
        </div>
    )
}

export default Footer;