const FooterHome = () => {
  return (
    <div className="bg-burgundy h-[210px] w-100% flex">
      <div className="flex justify-start mx-8 mt-8 flex-col">
        <h1 className="text-ivory font-quick text-xl font-medium">
          Resonance of The Archipelago
        </h1>
        <h1 className="text-ivory font-quick text-lg ms-14">
          © Ketloverz 2024. Made with 🩵 by Ketloverz.
        </h1>
      </div>
    </div>
  );
};

export default FooterHome;
