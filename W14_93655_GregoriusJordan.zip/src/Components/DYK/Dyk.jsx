import { useState, useEffect } from "react";
import axios from "axios";

const Dyk = () => {
  const [bahasa, setBahasaDaerah] = useState([]);
  const [provinsi, setProvinsi] = useState("");
  const [fakta, setFakta] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const url = "http://api.codespade.com:4517/codespade/api/bahasa-daerah/provinsi";

  const handleApi = async () => {
    try {
      const response = await axios.get(url);
      console.log("API Response:", response.data); // Debugging line to verify the response structure
      const data = response.data;
      setBahasaDaerah(data.bahasa.provinsi);
      if (data.listProvinsi.length > 0) {
        setProvinsi(data.listProvinsi[0].provinsi);
        setFakta(data.listProvinsi[0].deskripsi);
      }
      setLoading(false);
    } catch (error) {
      setError("Error fetching bahasa daerah");
      setLoading(false);
    }
  };

  useEffect(() => {
    handleApi();
  }, []);

  if (loading) {
    return <div className="flex justify-center">Loading...</div>;
  }

  if (error) {
    return <div className="flex justify-center">{error}</div>;
  }

  return (
    <div className="flex justify-center">
      <div>
        <h1 className="text-[40px] lg:text-[60px]">Do You Know?</h1>
        <div className="rounded-md lg:w-[1000px] w-[500px] bg-taupe p-4">
          <h2>Bahasa yang digunakan di provinsi {bahasa}:</h2>
        </div>
      </div>
    </div>
  );
};

export default Dyk;
