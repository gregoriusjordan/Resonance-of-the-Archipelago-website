import kendang from "../../Assets/kendang.png";


const Shelf = () => {

  // const handleClick = (event) => {
  //   event.preventDefault();
  //       console.log(event.target.id);
  // }

  return (
    <div className="flex justify-evenly mx-4 mb-16 flex-wrap">
      <div className="bg-burgundy h-[214px] w-[280px] rounded-[30px] relative mb-16 sm:mb-8 flex items-center justify-center flex-col" >
        <img src={kendang} className=" h-[70%] w-[70%] object-cover rounded-[45px] hover:scale-110 duration-[150ms]" alt="Kendang" />
    
      </div>
      <div className="bg-burgundy h-[214px] w-[280px] rounded-[30px] relative mb-16 sm:mb-8 flex items-center justify-center " >
        <img src={kendang} className=" h-[70%] w-[70%] object-cover rounded-[45px] hover:scale-110 duration-[150ms]" alt="Kendang" />
      </div>
      <div className="bg-burgundy h-[214px] w-[280px] rounded-[30px] relative mb-16 sm:mb-8 flex items-center justify-center " >
        <img src={kendang} className=" h-[70%] w-[70%] object-cover rounded-[45px] hover:scale-110 duration-[150ms]" alt="Kendang" />
      </div>
      <div className="bg-burgundy h-[214px] w-[280px] rounded-[30px] relative mb-16 sm:mb-8 flex items-center justify-center " >
        <img src={kendang} className=" h-[70%] w-[70%] object-cover rounded-[45px] hover:scale-110 duration-[150ms]"></img>
        </div>
      </div>
  ); 
};

export default Shelf;
