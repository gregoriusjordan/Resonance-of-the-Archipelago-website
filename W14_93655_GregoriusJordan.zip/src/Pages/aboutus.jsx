import React from "react";
import "./aboutus.css";
import Navbar from "../Components/Navbar/Navbar";

const AboutUs = () => {
  return (
    <div className="flex justify-center mt-28">
      <Navbar />
      <br/><br/><br/>
      <div>
        <div className="card mt-10">
          <p className="flex flex-col">
            <img src="./src/Assets/scaraflop.jpg"/>
            <span>Gregorius Jordan</span>
            </p>
          <p>
            <img src="./src/Assets/scaraflop.jpg"/>
            <span>Abraham Pilar</span>
          </p>
          <p>
            <img src="./src/Assets/scaraflop.jpg"/>
            <span>Qonita Azalia</span>
          </p>
          <p>
            <img src="./src/Assets/scaraflop.jpg"/>
            <span>Olivia Karissa</span>
          </p>
        </div>
        <br></br>
        <div className="text-below-card">
          Ketloverz
        </div>
        <br/><br/><br/>
      </div>
    </div>
  );
};

export default AboutUs;
