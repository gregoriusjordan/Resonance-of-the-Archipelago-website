import AlatMusikDetails from "../../Components/AlatMusik/AlatMusikDetail";
import alatMusik from "../../Data/alatMusik";
import AlatMusik from "../../Components/AlatMusik/AlatMusik";

const ResonanceDetails = (index) => {
    return(
        <div>
            
        </div>
    )
}

export default ResonanceDetails;