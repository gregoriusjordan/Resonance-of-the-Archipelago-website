import React from 'react';
import { Routes, Route, Outlet } from 'react-router-dom';
import ResonanceList from './ResonanceList';
import ResonanceDetails from './ResonanceDetails';
import Navbar from "../../Components/Navbar/Navbar";

const Resonance = () => (
  <div>
    <Navbar />
    <Outlet />
  </div>
);

const ResonanceRoutes = () => (
  <Routes>
    <Route path="/" element={<Resonance />}>
      <Route index element={<ResonanceList />} />
      <Route path="detail/:index" element={<ResonanceDetails />} />
    </Route>
  </Routes>
);

export default ResonanceRoutes;
